export function initEffects(){
  // placeholder for future shared hover/effect logic
  // intentionally minimal to keep performance on mobile
}